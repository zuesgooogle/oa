Ext.define('oa.view.user.UserController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.user'


});