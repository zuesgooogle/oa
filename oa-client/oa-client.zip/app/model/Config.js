Ext.define('oa.config.Config', {
    singleton: true,

    BASE_URL: 'http://47.93.85.206:9090/ws/'

});